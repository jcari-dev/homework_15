import React from 'react'

const Button = () => {
  return (
    <a href="#" className="btn btn-primary">Go somewhere</a>
  )
}

export default Button