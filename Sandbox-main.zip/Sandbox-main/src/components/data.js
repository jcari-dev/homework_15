let cardsArr = [ { 
img: "https://images.unsplash.com/photo-1536514072410-5019a3c69182?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60",
 title: "Santorini",
  text: "This was one of the most amazing places I've ever seen. A must see for eveyrone",
   url: "https://unsplash.com/s/photos/santorini" },
{ img: "https://images.unsplash.com/photo-1498712964741-5d33ab9e5017?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=600",
 title: "Zakynthos", text: "This was like being a pirate and we were looking to bury our treasure. It was so isolated and beautiful. ",
  url: "https://unsplash.com/s/photos/santorini" } ];

  export default cardsArr;
    